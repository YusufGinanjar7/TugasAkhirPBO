package com.ck.beststore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeststoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
